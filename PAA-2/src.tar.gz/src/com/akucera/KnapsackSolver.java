package com.akucera;

/**
 * Created by akucera on 30.10.16.
 */
public interface KnapsackSolver {
    public KnapsackInstance solve();
}
